#pragma once

//ヘッダーファイルのインクルード
#include <structer.h>

//ステージ情報を初期化する関数
void StageInfoInitialize(GameObject* go);

//ステージ構成の関数
void Stage1(GameObject* go, ImageInfo* ii);
void Stage2(GameObject* go, ImageInfo* ii);
void Stage3(GameObject* go, ImageInfo* ii);
void Stage4(GameObject* go, ImageInfo* ii);
void Stage5(GameObject* go, ImageInfo* ii);
void Stage6(GameObject* go, ImageInfo* ii);
void Stage7(GameObject* go, ImageInfo* ii);
void Stage8(GameObject* go, ImageInfo* ii);
void Stage9(GameObject* go, ImageInfo* ii);

void StageAggregate(GameObject* go);
