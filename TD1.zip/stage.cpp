//�w�b�_�[�t�@�C���̃C���N���[�h
#include <Novice.h>
#include <structer.h>
#include <stage.h>

//�O���[�o���ϐ��̐錾
#define verticalBlock 7
#define besideBlock 7

//�X�e�[�W�̏�������������֐�
void StageInfoInitialize(GameObject* go) {
	go->mapChip.stageNum = 0;
	int map[verticalBlock][besideBlock] = {
		{ 0, 0, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 0, 0, 0 },
	};

	for (int i = 0; i < besideBlock; i++) {
		for (int j = 0; j < verticalBlock; j++) {
			go->mapChip.map[j][i] = map[j][i];
		}
	}
};

//------------------------
//��1,player2,�G3,��4,��0
//------------------------
void Stage1(GameObject* go) {
	int map[verticalBlock][besideBlock] = {
		{1,1,1,1,1,1,0},
		{1,1,0,0,3,1,0},
		{1,0,2,0,0,1,0},
		{1,0,0,0,0,1,0},
		{1,3,0,0,0,1,0},
		{1,1,1,1,1,1,0},
		{0,0,0,0,0,0,0},
	};

	for (int i = 0; i < besideBlock; i++) {
		for (int j = 0; j < verticalBlock; j++) {
			go->mapChip.map[j][i] = map[j][i];
		}
	}
};

void Stage2(GameObject* go) {
	int map[verticalBlock][besideBlock] = {
		{ 1, 1, 1, 1, 1, 1, 0 },
		{ 1, 0, 3, 0, 2, 1, 0 },
		{ 1, 0, 0, 0, 0, 1, 0 },
		{ 1, 0, 0, 0, 0, 1, 0 },
		{ 1, 0, 0, 0, 3, 1, 0 },
		{ 1, 1, 1, 1, 1, 1, 0 },
		{ 0, 0, 0, 0, 0, 0, 0 }
	};

	for (int i = 0; i < 6; i++) {
		for (int j = 0; j < 6; j++) {
			go->mapChip.map[j][i] = map[j][i];
		}
	}
};

void Stage3(GameObject* go) {
	int map[verticalBlock][besideBlock] = {
		{ 1, 1, 1, 1, 1, 1, 0 },
		{ 1, 3, 0, 0, 2, 1, 0 },
		{ 1, 4, 0, 0, 3, 1, 0 },
		{ 1, 0, 0, 0, 0, 1, 0 },
		{ 1, 3, 0, 0, 1, 1, 0 },
		{ 1, 1, 1, 1, 1, 1, 0 },
		{ 0, 0, 0, 0, 0, 0, 0 },
	};

	for (int i = 0; i < 6; i++){
		for (int j = 0; j < 6; j++){
			go->mapChip.map[j][i] = map[j][i];
		}
	}
};

void Stage4(GameObject* go) {
	int map[verticalBlock][besideBlock] = {
		{ 1, 1, 1, 1, 1, 1, 0 },
		{ 1, 0, 0, 0, 0, 1, 0 },
		{ 1, 3, 0, 0, 0, 1, 0 },
		{ 1, 0, 0, 0, 0, 0, 0 },
		{ 1, 2, 3, 0, 0, 1, 0 },
		{ 1, 1, 1, 1, 1, 1, 0 },
		{ 0, 0, 0, 0, 0, 0, 0 },
	};

	for (int i = 0; i < 6; i++){
		for (int j = 0; j < 6; j++){
			go->mapChip.map[j][i] = map[j][i];
		}
	}
};

void Stage5(GameObject* go) {
	int map[verticalBlock][besideBlock] = {
		{ 1, 1, 1, 1, 1, 1, 0 },
		{ 1, 2, 0, 1, 0, 1, 0 },
		{ 1, 1, 0, 0, 0, 1, 0 },
		{ 1, 0, 0, 0, 0, 1, 0 },
		{ 1, 0, 3, 3, 3, 1, 0 },
		{ 1, 1, 1, 1, 1, 1, 0 },
		{ 0, 0, 0, 0, 0, 0, 0 },
	};

	for (int i = 0; i < 6; i++){
		for (int j = 0; j < 6; j++){
			go->mapChip.map[j][i] = map[j][i];
		}
	}
};

void Stage6(GameObject* go) {
	int map[verticalBlock][besideBlock] = {
		{ 1, 1, 1, 1, 1, 1, 0},
		{ 1, 0, 0, 0, 0, 1, 0},
		{ 1, 1, 3, 0, 0, 1, 0},
		{ 1, 0, 0, 3, 1, 1, 0},
		{ 1, 0, 0, 0, 2, 1, 0},
		{ 1, 1, 1, 1, 1, 1, 0},
		{ 0, 0, 0, 0, 0, 0, 0},
	};

	for (int i = 0; i < 6; i++) {
		for (int j = 0; j < 6; j++) {
			go->mapChip.map[j][i] = map[j][i];
		}
	}
};

void Stage7(GameObject* go) {
	int map[verticalBlock][besideBlock] = {
		{ 1, 1, 1, 1, 1, 1, 0},
		{ 1, 0, 3, 0, 0, 1, 0},
		{ 1, 0, 1, 2, 0, 1, 0},
		{ 1, 0, 0, 1, 0, 1, 0},
		{ 1, 0, 0, 0, 3, 1, 0},
		{ 1, 1, 1, 1, 1, 1, 0},
		{ 0, 0, 0, 0, 0, 0, 0},
	};

	for (int i = 0; i < 6; i++){
		for (int j = 0; j < 6; j++){
			go->mapChip.map[j][i] = map[j][i];
		}
	}
};

void Stage8(GameObject* go) {
	int map[verticalBlock][besideBlock] = {
		{ 1, 1, 1, 1, 1, 1, 0},
		{ 1, 2, 0, 0, 1, 3, 0},
		{ 1, 0, 0, 4, 3, 1, 0},
		{ 1, 0, 0, 0, 0, 1, 0},
		{ 1, 4, 0, 0, 3, 1, 0},
		{ 1, 1, 1, 1, 1, 1, 0},
		{ 0, 0, 0, 0, 0, 0, 0},
	};

	for (int i = 0; i < 6; i++){
		for (int j = 0; j < 6; j++){
			go->mapChip.map[j][i] = map[j][i];
		}
	}
};

void Stage9(GameObject* go) {
	int map[verticalBlock][besideBlock] = {
		{ 1, 1, 1, 1, 1, 1, 0},
		{ 3, 4, 0, 0, 0, 1, 0},
		{ 1, 0, 3, 0, 0, 1, 0},
		{ 1, 0, 0, 4, 3, 1, 0},
		{ 1, 0, 0, 0, 3, 1, 0},
		{ 1, 1, 1, 1, 1, 1, 0},
		{ 0, 0, 0, 0, 0, 0, 0},
	};

	for (int i = 0; i < 6; i++) {
		for (int j = 0; j < 6; j++) {
			go->mapChip.map[j][i] = map[j][i];
		}
	}
};
